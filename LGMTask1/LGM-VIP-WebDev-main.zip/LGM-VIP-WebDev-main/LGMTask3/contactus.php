<?php include('topbar.php');?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/contactus.css">
	<title></title>
</head>
<body style="background-color: skyblue;">
    <br><br><br>
    <div class="box" >
    	<center><u><h1>Contact</h1></u></center>
         <ul style="font-size: 30px;">
         	<li>Location - Bengaluru</li>
			 <li>State - Karnataka</li>
            <li>Pin - 560022</li>
         	<li>Contact no - +91 9525987622</li>
         </ul>
         <center><h2>Thank you!</h2></center>
    </div>
</body>
</html>