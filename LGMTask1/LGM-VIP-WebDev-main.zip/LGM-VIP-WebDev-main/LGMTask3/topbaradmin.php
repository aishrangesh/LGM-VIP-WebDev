<?php session_start(); ?>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!-- this link is for symbols -->
    <link rel="stylesheet" type="text/css" href="css/topbaradmin.css">
</head>
<body>

<ul class="uperchipkao ul-horizontal" >
    <li style="margin-top: -15px;margin-left: -15px" class="li-horizontal aise_he"><a href="adminpanel.php">Student Result Management System | ADMIN</a></li>
    <div style="float:right"> 
        <li class="li-horizontal" ><a href="contactus.php">Contact</a></li>
        <li class="li-horizontal"><a href="aboutus.php">About</a></li>
        <li class="li-horizontal">
            <a href="index.php">
                <i style="font-size:24px" class="fa">&#xf08b;
                </i>
            </a>
        </li>


    </div>
</ul>

</body>
</html>