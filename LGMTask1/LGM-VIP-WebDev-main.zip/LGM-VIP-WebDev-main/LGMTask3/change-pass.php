<html>
<head>
    <title>Change Password</title>
    <link rel="stylesheet" type="text/css" href="css/change-pass.css">
</head>
<body>
    <div >
        <header>
            <?php  include('topbaradmin.php');?>
        </header>
    </div>
    <div>
        <?php include('leftbar.php');?>
    </div>

    <div style="margin-left:25%;padding:1px 16px;height:1000px;">
    <br><br><br><br>
        <div class="box">
            <?php include('pass-cng-form.php') ?>
        </div>
    </div>


</body>
</html>