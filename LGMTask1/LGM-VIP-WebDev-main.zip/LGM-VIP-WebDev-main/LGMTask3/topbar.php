<!DOCTYPE html>
<html>
    <head>
        <title>TOPBAR</title>
        <link rel="stylesheet" type="text/css" href="css/topbar.css">
    </head>
<body style="float:top">
<ul class="uperchipkao, ul-horizontal" >
        <li class="li-horizontal aise_he"><a href="index.php"> Student Result Management System</a></li>
    <div style="float:right">
        <li class="li-horizontal" ><a href="contactus.php">Contact</a></li>
        <li class="li-horizontal"><a href="aboutus.php">About</a></li>
    </div>
</ul>

</body>
</html>
