<!DOCTYPE html>
<html>
<head>
    <title>AdminPanel</title>
    <link rel="stylesheet" type="text/css" href="css/leftbar.css">
</head>
<body>
<ul class="ul-verticle">
    <div class="li-verticle">
        <li><a href="enter-result.php">Enter<br>Result</a></li>
        <li><a href="update-result.php">Update<br>Result</a></li>
        <li><a href="view-result.php">View<br>Details</a></li>
        <li><a href="delete-result.php">Delete<br>Details</a></li>
        <li><a href="change-pass.php">Admin Change<br>Password</a></li>
        <img src="img/work.png" style="margin-left: 10px; margin-top: 10px; height: 300px" >
    </div>
</ul>



</body>
</html>