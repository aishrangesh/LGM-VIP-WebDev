<?php
    echo '<script>alert("Welcome Admin")</script>';
?>
<!DOCTYPE html>
<html>
<head>
    <title>AdminPanel</title>
    <link rel="stylesheet" type="text/css" href="css/adminpanel.css">
</head>
<body>
    <div>
        <header>
            <?php include('topbaradmin.php');?>
        </header>
    </div>
    <div >
        <?php include('leftbar.php');?>
    </div>

<div style="margin-left:25%;padding:1px 16px;height:1000px;">
    <br><br><br><br>
    <div >
        <!-- <?php //start coding here ?><img  width="100%" src="adminimg.png"> -->
    </div>
</div>


</body>
</html>