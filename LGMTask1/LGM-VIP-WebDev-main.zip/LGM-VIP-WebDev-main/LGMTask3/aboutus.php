<?php include('topbar.php');?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/aboutus.css">
</head>
<body>

<div class="about-section">
  <h1>Aishwarya Rangesh</h1>
</div>

<h2 style="text-align:center">About me</h2>
<p style="text-align:center">
               <img src="img/pic.jpeg" alt="Aishwarya Rangesh" style="width:30%">
               <center>
                    <h2>Details</h2>
                    <p>I'm a third year undergraduate currently interning at LetsGrowMore</p>
                    <p>Ph No.   :   +91 - 9525987622</p>
                    <p>aishwaryarangesh6@gmail.com</p>
                    <p><a href="https://forms.gle/dJRt4DuWtqh417n19"> <button class="button">Contact Me</button></a></p>
                    </center>
</div>
</p>  
</body>
</html>
