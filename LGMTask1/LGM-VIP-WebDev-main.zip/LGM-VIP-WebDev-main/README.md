# LGM-VIP-WebDev

LGMVIP-WebDev
These are just a set of tasks I've completed as an intern in the month of July(2021).

TASK 1 CREATE A SINGLE PAGE WEBSITE USING HTML, CSS AND JAVASCRIPT. IDE used : Visual Studio Code


TASK 3

The software application unbelievably unravels and quickens the result management system with unique templates by providing the administration a secure database system for storing, evaluating and publishing the test scores and grades of candidates online. The database likewise allows the students to observe and gander at the exam results on the web at whatever point necessary.

Student Result Management System is a technological opportunity for the school, college, university and coaching centre institutions searching for a secure, simple and alternative solution to the conventional paper-based exam results evaluation, reporting and distribution. Like any other software, the system comes with certain advantage and disadvantage

IDE used : Visual Studio Code Languages / Prerequisites: HTML, CSS, JAVASCRIPT, PHP and MySQL.
